import React, { Component } from 'react'
import { getUser } from '../actions/mainActions'
import { connect } from 'react-redux';
import MainCard from '../component/MainCard';

export class WorkerPage extends Component {
  componentDidMount() {
    this.props.getUser()
  }

  getAfterDelete = () => {
    this.props.getUser()
  }
  render() {
    const { user } = this.props
    console.log(user);

    return (

      <div className='container'>
        <div className='grid_container'>
          {
            user.map((data, i) => {
              console.log(data.firs_name);
              return (
                <MainCard firs_name={data.firs_name} last_name={data.last_name} phone_number={data.phone_number} email={data.email} password={data.password} key={i} url={`user/${data.id}`} getAfterDelete={this.getAfterDelete}/>
              )
            })
          }
        </div>
      </div>
    )

  }
}

const mapStateToProps = (state) => ({
  user: state.Data.user
})
const mapDispatchToProps = { getUser }
export default connect(mapStateToProps, mapDispatchToProps)(WorkerPage)