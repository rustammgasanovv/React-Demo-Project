import React, { Component } from 'react'

export class AddBtn extends Component {
  render() {
    return (
        <div className='container'>
        <button className='add_btn'>Add</button>
        </div>
    )
  }
}

export default AddBtn