import React, { Component } from 'react'

export class AvailableBrPage extends Component {
  render() {
    return (
      <div>AvailableBrPage</div>
    )
  }
}

export default AvailableBrPage