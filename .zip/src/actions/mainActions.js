import axios from "axios"
import { mainApi } from "../api"
import { changeStateValue } from "../redux/MainReducer";

export const getCars = () => async dispatch => {
    return await axios.get(`${mainApi}/cars`)
    .then(resp => {
        console.log(resp.data);
        dispatch(changeStateValue({
            name:'cars',
            value:resp.data
        }))
    })
}

export const deleteItem = (url, data) => async dispatch => {
    console.log(data);
    return await axios.delete(`${mainApi}/${url}`, data)
    .then(resp=>{
        return 'success'
    }).catch(err => {return'error'})
}

export const getUser = () => async dispatch =>{
    return await axios.get(`${mainApi}/user`)
    .then(resp=>{
        console.log(resp.data);
        dispatch(changeStateValue({
            name:'user',
            value: resp.data
        }))
    })
}

export const getBranch = () => async dispatch => {
    return await axios.get(`${mainApi}/branch`)
    .then(resp => {
        console.log(resp.data);
        dispatch(changeStateValue({
            name:'branch',
            value:resp.data
        }))
    })
}

export const getOrders = () => async dispatch => {
    return await axios.get(`${mainApi}/order`)
    .then(resp => {
        console.log(resp.data);
        dispatch(changeStateValue({
            name:'order',
            value:resp.data
        }))
    })
}