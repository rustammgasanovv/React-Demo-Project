export const initialState = {
    cars:[],
    user:[],
    branch:[],
    orders:[]
}