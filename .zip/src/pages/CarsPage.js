import React, { Component } from 'react'
import { getCars } from '../actions/mainActions'
import { connect } from 'react-redux'
import MainCard from '../component/MainCard'

export class CarsPage extends Component {
  componentDidMount(){
    this.props.getCars()
  }
  getAfterDelete = () => {
    this.props.getCars()
  }
  render() {
    const {cars} = this.props
    return (
      <div className='container'>
            <div className='grid_container'>
              {
                cars.map((data,i)=>{
                  console.log('map',data);
                  return(
                    <MainCard key={i} model={data.model} plate_number = {data.plate_number} url={`cars/${data.id}`} getAfterDelete={this.getAfterDelete}/>
                  )
                })
              }
            </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  cars:state.Data.cars
})

const mapDispatchToProps = {getCars}
export default connect(mapStateToProps,mapDispatchToProps) (CarsPage)